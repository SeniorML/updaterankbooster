#!/bin/bash

# Daftar aplikasi yang akan dioptimalkan
app_packages="com.abox.apps,com.dts.freefireth,com.mojang.minecraftpe.patch,com.mojang.minecraftpe,com.rockstargames.gtasa,com.mobile.legends"

##################################
# ANGLE Driver Setup
##################################
echo ""
echo "> Removing ANGLE Trigger Driver:"
settings delete global angle_gl_driver_selection_values
echo ""
sleep 2

echo "> Setting ANGLE Trigger Driver for apps:"
settings put global angle_gl_driver_selection_pkgs "$app_packages"
settings put global angle_gl_driver_selection_values angle

echo "> Updated ANGLE Trigger Driver:"
for app in $(echo $app_packages | tr ',' '\n'); do
    echo "- ${app} Success"
    sleep 1
done
echo "__________________________________________________________________"

##################################
# Vulkan Driver Setup
##################################
echo ""
echo "> Removing Vulkan Trigger Driver:"
settings delete global vulkan_gl_driver_selection_values
echo ""
sleep 2

echo "> Setting Vulkan Trigger Driver for apps:"
settings put global vulkan_gl_driver_selection_pkgs "$app_packages"
settings put global vulkan_gl_driver_selection_values vulkan

echo "> Updated Vulkan Trigger Driver:"
for app in $(echo $app_packages | tr ',' '\n'); do
    echo "- ${app} Success"
    sleep 1
done
echo "__________________________________________________________________"

##################################
# Game Driver Preferences Setup
##################################
echo ""
echo "> Removing input Driver:"
settings delete global updatable_driver_prerelease_opt_in_apps
sleep 1
settings delete global game_driver_opt_in_apps
sleep 1
settings delete global updatable_driver_production_opt_out_apps
sleep 1
echo ""

echo "> Updating Game Driver Preferences for apps:"
settings put global updatable_driver_production_opt_in_apps "$app_packages"
sleep 1
for app in $(echo $app_packages | tr ',' '\n'); do
    echo "- ${app} Success"
    sleep 1
done
sleep 2
echo ""

##################################
# QuantumFPS Settings
##################################
echo "> Applying QuantumFPS to apps:"
for app in $(echo $app_packages | tr ',' '\n'); do
    echo "- ${app}"
    sleep 1
done
echo "__________________________________________________________________"

##################################
# End of Tweaks
##################################